// SFX সিন্থেসাইজার — কোনো ডাউনলোড বা ডিপেন্ডেন্সি ছাড়া, সম্পূর্ণ নির্ধারিত (deterministic)।
// আউটপুট: public/sfx/{pop,click,whoosh,chime,thud}.wav (16-bit, mono, 44.1kHz)
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const SR = 44100;
const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
fs.mkdirSync(dir, { recursive: true });

// নির্ধারিত নয়েজ (LCG)
let seed = 1234567;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 0xffffffff;
};
const noise = () => rnd() * 2 - 1;

const make = (sec, fn) => {
  const n = Math.round(sec * SR);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(i / SR, i);
  return out;
};

// এক-পোল লো-পাস / হাই-পাস
const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  const y = new Float32Array(x.length);
  let s = 0;
  for (let i = 0; i < x.length; i++) {
    s += a * (x[i] - s);
    y[i] = s;
  }
  return y;
};
const highpass = (x, fc) => {
  const lp = lowpass(x, fc);
  return x.map((v, i) => v - lp[i]);
};

// খুব ছোট রিভার্ব: কয়েকটি ট্যাপ-ইকো, tail `tail` সেকেন্ড বাড়ায়
const reverb = (x, mix = 0.1, tail = 0.08) => {
  const taps = [
    [0.019, 0.5],
    [0.031, 0.36],
    [0.047, 0.24],
    [0.063, 0.14],
  ];
  const y = new Float32Array(x.length + Math.round(tail * SR));
  for (let i = 0; i < x.length; i++) y[i] += x[i];
  for (const [d, g] of taps) {
    const off = Math.round(d * SR);
    for (let i = 0; i < x.length; i++) if (i + off < y.length) y[i + off] += x[i] * g * mix * 2;
  }
  return y;
};

// শেষে ৮ms ফেড (ক্লিক এড়াতে)
const fadeTail = (x, ms = 8) => {
  const n = Math.round((ms / 1000) * SR);
  for (let i = 0; i < n && i < x.length; i++) x[x.length - 1 - i] *= i / n;
  return x;
};

// ---- সাউন্ডগুলো ----

// pop: দ্রুত নিচে নামা pitch-সহ sine + ছোট envelope
const pop = () => {
  let phase = 0;
  const raw = make(0.2, (t) => {
    const f = 190 + 420 * Math.exp(-t / 0.035);
    phase += (2 * Math.PI * f) / SR;
    const env = (1 - Math.exp(-t / 0.003)) * Math.exp(-t / 0.05);
    return (Math.sin(phase) + 0.16 * Math.sin(2 * phase)) * env;
  });
  return fadeTail(reverb(lowpass(raw, 4200), 0.1, 0.06));
};

// click: high-pass করা ছোট noise burst + খুব হালকা টোন
const click = () => {
  const raw = make(0.1, (t) => {
    const env = (1 - Math.exp(-t / 0.0006)) * Math.exp(-t / 0.007);
    const tone = Math.sin(2 * Math.PI * 1900 * t) * Math.exp(-t / 0.004) * 0.35;
    return (noise() * 0.9 + tone) * env;
  });
  return fadeTail(reverb(lowpass(highpass(raw, 1600), 7000), 0.06, 0.03));
};

// whoosh: band-pass noise sweep, fade in/out
const whoosh = () => {
  const len = 0.62;
  let low = 0;
  let band = 0;
  const raw = make(len, (t) => {
    const tt = t / len;
    const fc = 320 + 2800 * Math.pow(tt, 1.4);
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    const q = 0.85;
    const x = noise();
    low += f * band;
    const high = x - low - q * band;
    band += f * high;
    const env = Math.pow(Math.sin(Math.PI * Math.pow(tt, 0.8)), 1.6);
    return band * env;
  });
  return fadeTail(reverb(lowpass(raw, 5500), 0.08, 0.08));
};

// chime: নরম ওভারটোনসহ ছোট decay
const chime = () => {
  const partials = [
    [1, 1, 0.2],
    [2.0, 0.38, 0.13],
    [3.01, 0.16, 0.09],
    [4.2, 0.07, 0.05],
  ];
  const base = 988;
  const raw = make(0.4, (t) => {
    const attack = 1 - Math.exp(-t / 0.006);
    let s = 0;
    for (const [m, g, tau] of partials) s += Math.sin(2 * Math.PI * base * m * t) * g * Math.exp(-t / tau);
    return s * attack;
  });
  return fadeTail(reverb(lowpass(raw, 6000), 0.14, 0.1));
};

// thud: খুব হালকা সফট থাড (হুকের জন্য, সংযত)
const thud = () => {
  let phase = 0;
  const raw = make(0.36, (t) => {
    const f = 46 + 60 * Math.exp(-t / 0.06);
    phase += (2 * Math.PI * f) / SR;
    const env = (1 - Math.exp(-t / 0.008)) * Math.exp(-t / 0.09);
    return Math.sin(phase) * env;
  });
  return fadeTail(reverb(lowpass(raw, 420), 0.05, 0.04));
};

// ---- WAV লেখা ----
// লক্ষ্য peak সব সাউন্ডে একই (0.9); Remotion-এ volume 0.2–0.35 দিয়ে মিশবে।
const PEAK = 0.9;
const write = (name, x) => {
  let peak = 0;
  for (const v of x) peak = Math.max(peak, Math.abs(v));
  const g = PEAK / (peak || 1);
  const data = Buffer.alloc(x.length * 2);
  x.forEach((v, i) => data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, v * g)) * 32767), i * 2));
  const h = Buffer.alloc(44);
  h.write("RIFF", 0);
  h.writeUInt32LE(36 + data.length, 4);
  h.write("WAVEfmt ", 8);
  h.writeUInt32LE(16, 16);
  h.writeUInt16LE(1, 20);
  h.writeUInt16LE(1, 22);
  h.writeUInt32LE(SR, 24);
  h.writeUInt32LE(SR * 2, 28);
  h.writeUInt16LE(2, 32);
  h.writeUInt16LE(16, 34);
  h.write("data", 36);
  h.writeUInt32LE(data.length, 40);
  fs.writeFileSync(path.join(dir, `${name}.wav`), Buffer.concat([h, data]));
  console.log(`wrote ${name}.wav (${(x.length / SR).toFixed(2)}s)`);
};

write("pop", pop());
write("click", click());
write("whoosh", whoosh());
write("chime", chime());
write("thud", thud());
