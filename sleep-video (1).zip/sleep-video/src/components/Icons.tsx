import React from "react";
import { theme } from "../theme";

// সব আইকন SVG, থিমের রঙে। ইমোজি নয়।
// draw: ০→১ — স্ট্রোক আঁকা হওয়ার অগ্রগতি (pathLength=1 কৌশল)
const draw = (p: number) => ({
  pathLength: 1,
  strokeDasharray: 1,
  strokeDashoffset: 1 - Math.min(1, Math.max(0, p)),
});

const strokeBase = {
  fill: "none",
  strokeLinecap: "round",
  strokeLinejoin: "round",
} as const;

export const BrainIcon: React.FC<{ size: number; p: number; color?: string }> = ({
  size,
  p,
  color = theme.colors.text,
}) => (
  <svg width={size} height={(size * 160) / 200} viewBox="0 0 200 160">
    <g {...strokeBase} stroke={color} strokeWidth={5.5}>
      <path
        {...draw(p)}
        d="M100 22 C80 8 50 14 44 38 C24 40 12 62 24 80 C12 96 24 122 46 122 C52 142 84 148 100 132"
      />
      <path
        {...draw(p)}
        d="M100 22 C120 8 150 14 156 38 C176 40 188 62 176 80 C188 96 176 122 154 122 C148 142 116 148 100 132"
      />
      <path {...draw(p)} d="M100 22 C94 60 106 90 100 132" />
      <path {...draw(p - 0.15)} d="M44 38 C56 48 70 46 78 56" />
      <path {...draw(p - 0.15)} d="M24 80 C40 78 52 86 60 78" />
      <path {...draw(p - 0.15)} d="M46 122 C60 110 76 112 84 100" />
      <path {...draw(p - 0.15)} d="M156 38 C144 48 130 46 122 56" />
      <path {...draw(p - 0.15)} d="M176 80 C160 78 148 86 140 78" />
      <path {...draw(p - 0.15)} d="M154 122 C140 110 124 112 116 100" />
    </g>
  </svg>
);

export const HeartIcon: React.FC<{ size: number; p: number; beat?: number }> = ({
  size,
  p,
  beat = 1,
}) => (
  <svg width={size} height={size} viewBox="0 0 200 200">
    <g style={{ transformOrigin: "100px 100px", transform: `scale(${beat})` }}>
      <path
        d="M100 168 C22 112 20 52 64 42 C88 37 100 56 100 62 C100 56 112 37 136 42 C180 52 178 112 100 168 Z"
        {...strokeBase}
        stroke={theme.colors.text}
        strokeWidth={7}
        {...draw(p)}
        fill={theme.colors.primarySoft}
        fillOpacity={Math.min(1, Math.max(0, (p - 0.6) / 0.4))}
      />
      <polyline
        points="22,104 70,104 86,72 108,136 124,94 138,104 178,104"
        {...strokeBase}
        stroke={theme.colors.accent}
        strokeWidth={7}
        {...draw(p - 0.25)}
      />
    </g>
  </svg>
);

// প্রেশার গেজ: আর্ক + কাঁটা। angle: -80 (নিচু) … +80 (উঁচু)
export const GaugeIcon: React.FC<{ size: number; p: number; angle: number }> = ({
  size,
  p,
  angle,
}) => (
  <svg width={size} height={size} viewBox="0 0 200 200">
    <path
      d="M30 140 A70 70 0 0 1 170 140"
      {...strokeBase}
      stroke={theme.colors.track}
      strokeWidth={16}
    />
    <path
      d="M30 140 A70 70 0 0 1 170 140"
      {...strokeBase}
      stroke={theme.colors.primary}
      strokeWidth={16}
      {...draw(p)}
    />
    {Array.from({ length: 7 }).map((_, i) => {
      const a = ((-90 + (i * 180) / 6) * Math.PI) / 180;
      const cx = 100;
      const cy = 140;
      return (
        <line
          key={i}
          x1={cx + Math.cos(a) * 88}
          y1={cy + Math.sin(a) * 88}
          x2={cx + Math.cos(a) * 100}
          y2={cy + Math.sin(a) * 100}
          stroke={theme.colors.textDim}
          strokeWidth={4}
          strokeLinecap="round"
          opacity={p}
        />
      );
    })}
    <g style={{ transformOrigin: "100px 140px", transform: `rotate(${angle}deg)` }}>
      <line
        x1={100}
        y1={140}
        x2={100}
        y2={66}
        stroke={theme.colors.accent}
        strokeWidth={8}
        strokeLinecap="round"
      />
    </g>
    <circle cx={100} cy={140} r={13} fill={theme.colors.text} />
  </svg>
);

// রক্তের ফোঁটা: ভেতরের লেভেল level (০→১) ওপরে উঠে
export const DropIcon: React.FC<{ size: number; p: number; level: number; id: string }> = ({
  size,
  p,
  level,
  id,
}) => {
  const d =
    "M100 24 C100 24 44 96 44 130 A56 56 0 0 0 156 130 C156 96 100 24 100 24 Z";
  const top = 186 - level * 150;
  return (
    <svg width={size} height={size} viewBox="0 0 200 200">
      <defs>
        <clipPath id={id}>
          <path d={d} />
        </clipPath>
      </defs>
      <g clipPath={`url(#${id})`}>
        <rect x={30} y={top} width={140} height={190} fill={theme.colors.accent} opacity={0.9} />
        <rect x={30} y={top} width={140} height={6} fill={theme.colors.text} opacity={0.5} />
      </g>
      <path d={d} {...strokeBase} stroke={theme.colors.text} strokeWidth={7} {...draw(p)} />
    </svg>
  );
};

export const ArrowDown: React.FC<{ size: number; color?: string }> = ({
  size,
  color = theme.colors.accent,
}) => (
  <svg width={size} height={size} viewBox="0 0 48 48">
    <path
      d="M24 8 V38 M10 26 L24 40 L38 26"
      {...strokeBase}
      stroke={color}
      strokeWidth={6}
    />
  </svg>
);

export const ArrowUp: React.FC<{ size: number; color?: string }> = ({
  size,
  color = theme.colors.accent,
}) => (
  <svg width={size} height={size} viewBox="0 0 48 48">
    <path
      d="M24 40 V10 M10 22 L24 8 L38 22"
      {...strokeBase}
      stroke={color}
      strokeWidth={6}
    />
  </svg>
);

export const CheckIcon: React.FC<{ size: number; p: number; color?: string }> = ({
  size,
  p,
  color = theme.colors.accent,
}) => (
  <svg width={size} height={size} viewBox="0 0 48 48">
    <path
      d="M10 25 L20 35 L39 14"
      {...strokeBase}
      stroke={color}
      strokeWidth={6}
      {...draw(p)}
    />
  </svg>
);
