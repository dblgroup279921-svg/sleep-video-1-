import React from "react";
import { Audio, Sequence, staticFile } from "remotion";

export type SfxName = "pop" | "click" | "whoosh" | "chime" | "thud";

// একটি SFX: `at` ফ্রেমে শুরু (সিনের লোকাল ফ্রেম)। rate দিয়ে পরপর একই সাউন্ডে সামান্য pitch ভ্যারিয়েশন।
export const Sfx: React.FC<{
  name: SfxName;
  at: number;
  volume?: number;
  rate?: number;
}> = ({ name, at, volume = 0.3, rate = 1 }) => (
  <Sequence from={Math.max(0, Math.round(at))} layout="none">
    <Audio src={staticFile(`sfx/${name}.wav`)} volume={volume} playbackRate={rate} />
  </Sequence>
);
