// সব ফ্রেম-হিসাব এখানে, SRT থেকে। কোনো সংখ্যা হাতে বসানো নেই।
import { video } from "./theme";
import { Cue, SRT, parseSrt } from "./srt";

export const LEAD = 5; // ভিজ্যুয়াল কথার এত ফ্রেম আগে ঢোকে (৪-৬ ফ্রেম নিয়ম)
export const OVERLAP = 8; // ট্রানজিশনে দুই সিন যত ফ্রেম একসাথে থাকে

const toFrame = (sec: number) => Math.round(sec * video.fps);

export const cues: Cue[] = parseSrt(SRT);
export const totalFrames = toFrame(cues[cues.length - 1].end);

const cueStartFrame = (c: Cue) => toFrame(c.start);
const cueDurFrames = (c: Cue) => toFrame(c.end) - toFrame(c.start);

// cue-র টেক্সটে শব্দটি কত অনুপাতে আছে → কথাটি cue-র কোন ফ্রেমে বলা হবে তার আনুমানিক হিসাব।
export function offsetOf(cue: Cue, word: string): number {
  const idx = cue.text.indexOf(word);
  if (idx < 0) throw new Error(`"${word}" cue ${cue.index}-এ পাওয়া যায়নি`);
  return Math.round((idx / cue.text.length) * cueDurFrames(cue));
}

// একাধিক আইটেম: প্রথম ও শেষ আইটেমের অবস্থান cue-র টেক্সট থেকে, মাঝেরগুলো সমান ব্যবধানে।
// ফল: সিনের শুরু থেকে গোনা লোকাল ফ্রেম (LEAD আগেই হিসাবে ধরা)।
export function slots(cue: Cue, first: string, last: string, n: number): number[] {
  const a = offsetOf(cue, first);
  const b = offsetOf(cue, last);
  if (n === 1) return [a];
  return Array.from({ length: n }, (_, i) => Math.round(a + ((b - a) * i) / (n - 1)));
}

export type SceneTiming = { from: number; duration: number };

// সিনের তালিকা: [হুক (cue-র আগে), cue ১, ২, ৩, ৪]
const froms: number[] = [0, ...cues.map((c) => cueStartFrame(c) - LEAD)];
const scenes: SceneTiming[] = froms.map((from, i) => {
  const next = froms[i + 1];
  return {
    from,
    duration: next !== undefined ? next - from + OVERLAP : totalFrames - from,
  };
});

const [c1, c2, c3, c4] = cues;

export const T = {
  hook: scenes[0],
  brain: {
    ...scenes[1],
    items: slots(c1, "মনোযোগ", "সিদ্ধান্ত", 3),
  },
  mood: {
    ...scenes[2],
    items: slots(c2, "মেজাজ", "ক্লান্ত", 2),
  },
  risk: {
    ...scenes[3],
    items: slots(c3, "হৃদরোগ", "ডায়াবেটিস", 3),
  },
  habit: {
    ...scenes[4],
    // প্রথম বাক্য শেষ হয়ে দ্বিতীয় বাক্য শুরু
    split: offsetOf(c4, "প্রাপ্তবয়স্কদের"),
    // "অন্তত ৭ ঘণ্টা" বলার মুহূর্ত
    seven: offsetOf(c4, "অন্তত"),
  },
} as const;

// ট্রানজিশন whoosh: নতুন সিন ঢোকার ৩ ফ্রেম আগে
export const transitionFrames: number[] = scenes.slice(1).map((s) => s.from - 3);
