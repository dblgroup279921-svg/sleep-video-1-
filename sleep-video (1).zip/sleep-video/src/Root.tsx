import React from "react";
import { Composition } from "remotion";
import "./fonts";
import { Main } from "./Main";
import { video } from "./theme";
import { totalFrames } from "./timing";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    width={video.width}
    height={video.height}
    fps={video.fps}
    durationInFrames={totalFrames}
  />
);
