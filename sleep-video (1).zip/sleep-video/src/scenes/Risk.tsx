import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Card } from "../components/Card";
import { ArrowUp, DropIcon, GaugeIcon, HeartIcon } from "../components/Icons";
import { Entrance, SceneShell, Words, clamp01, useSpring } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { T } from "../timing";

// সিন ৪ (cue ৩): Glass Cards — তিনটি দীর্ঘমেয়াদি ঝুঁকি
const CARD = { w: 920, h: 300, y: 520, gap: 40 };
const LABELS = ["হৃদরোগ", "উচ্চ রক্তচাপ", "ডায়াবেটিস"];
const RATES = [1, 1.05, 0.96];
const left0 = (1080 - CARD.w) / 2;

const RiskCard: React.FC<{ index: number; at: number }> = ({ index, at }) => {
  const frame = useCurrentFrame();
  const local = frame - at;
  const draw = interpolate(local, [3, 32], [0, 1], { easing: theme.ease.out, ...clamp01 });
  const risk = interpolate(local, [22, 64], [0, 0.84], {
    easing: theme.ease.inOut,
    ...clamp01,
  });
  const arrow = useSpring(at + 44, "bouncy");
  const swing = useSpring(at + 18, "bouncy");

  let icon: React.ReactNode = null;
  if (index === 0) {
    const beat = 1 + 0.06 * Math.max(0, Math.sin(local / 5)) ** 2 * (local > 30 ? 1 : 0);
    icon = <HeartIcon size={210} p={draw} beat={beat} />;
  } else if (index === 1) {
    icon = <GaugeIcon size={210} p={draw} angle={interpolate(swing, [0, 1], [-78, 56])} />;
  } else {
    icon = <DropIcon size={210} p={draw} level={risk * 0.9} id={`drop-${index}`} />;
  }

  return (
    <Entrance
      delay={at}
      y={46}
      style={{ position: "absolute", left: left0, top: CARD.y + index * (CARD.h + CARD.gap) }}
    >
      <Card width={CARD.w} height={CARD.h}>
        <div
          style={{
            position: "absolute",
            left: 40,
            top: 44,
            width: 220,
            height: 220,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {icon}
        </div>
        <div
          style={{
            position: "absolute",
            left: 300,
            right: 40,
            top: 58,
            display: "flex",
            justifyContent: "flex-start",
          }}
        >
          <Words text={LABELS[index]} size={68} delay={at + 8} per={5} />
        </div>
        <div
          style={{
            position: "absolute",
            left: 300,
            right: 44,
            bottom: 50,
            display: "flex",
            alignItems: "center",
            gap: 20,
          }}
        >
          <div
            style={{
              fontFamily: theme.fonts.body,
              fontWeight: theme.weights.strong,
              fontSize: 40,
              lineHeight: 1.4,
              color: theme.colors.textDim,
              letterSpacing: 0,
            }}
          >
            ঝুঁকি
          </div>
          <div
            style={{
              flex: 1,
              height: 18,
              borderRadius: theme.radius.pill,
              background: theme.colors.track,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                width: `${risk * 100}%`,
                height: "100%",
                borderRadius: theme.radius.pill,
                background: theme.colors.accent,
              }}
            />
          </div>
          <div
            style={{
              opacity: Math.min(1, Math.max(0, arrow)),
              transform: `translateY(${interpolate(arrow, [0, 1], [14, 0])}px)`,
            }}
          >
            <ArrowUp size={44} />
          </div>
        </div>
      </Card>
    </Entrance>
  );
};

export const Risk: React.FC = () => {
  const frame = useCurrentFrame();
  const sweep = interpolate(frame, [14, 36], [0, 1], { easing: theme.ease.out, ...clamp01 });
  const items = T.risk.items;
  return (
    <SceneShell>
      <AbsoluteFill>
        {/* শিরোনাম: "ঘাটতি" শব্দে হাইলাইট সুইপ */}
        <div
          style={{
            position: "absolute",
            left: 0,
            right: 0,
            top: 300,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            columnGap: 26,
            fontFamily: theme.fonts.display,
            fontWeight: theme.weights.display,
            fontSize: 100,
            lineHeight: 1.4,
            letterSpacing: 0,
            color: theme.colors.text,
          }}
        >
          <Words text="দীর্ঘদিন ঘুমের" size={100} delay={0} per={4} />
          <Entrance delay={8} y={30}>
            <span style={{ position: "relative", display: "inline-block", padding: "0 18px" }}>
              <span
                style={{
                  position: "absolute",
                  left: 0,
                  right: 0,
                  top: 18,
                  bottom: 14,
                  borderRadius: theme.radius.small,
                  background: theme.colors.accentSoft,
                  transformOrigin: "left center",
                  transform: `scaleX(${sweep})`,
                }}
              />
              <span style={{ position: "relative", color: theme.colors.accent }}>ঘাটতি</span>
            </span>
          </Entrance>
        </div>

        {items.map((at, i) => (
          <RiskCard key={i} index={i} at={at} />
        ))}
      </AbsoluteFill>

      <Sfx name="click" at={20} volume={0.32} />
      {items.map((at, i) => (
        <Sfx key={i} name="pop" at={at - 2} volume={0.26} rate={RATES[i]} />
      ))}
    </SceneShell>
  );
};
