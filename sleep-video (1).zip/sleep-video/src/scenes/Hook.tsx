import React from "react";
import { AbsoluteFill, interpolate, random, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { SceneShell, Words, useSpring } from "../components/Motion";
import { Sfx } from "../components/Sfx";

// সিন ১ (০–৫ সেকেন্ড, কোনো cue নেই): Kinetic Typography + চাঁদ
const STARS = Array.from({ length: 28 }, (_, i) => ({
  x: 40 + random(`sx${i}`) * 1000,
  y: 120 + random(`sy${i}`) * 1680,
  r: 2 + random(`sr${i}`) * 3.5,
  ph: random(`sp${i}`) * 6.28,
}));

const Zed: React.FC<{ delay: number; size: number; x: number; y: number }> = ({
  delay,
  size,
  x,
  y,
}) => {
  const frame = useCurrentFrame();
  const p = useSpring(delay, "bouncy");
  const rise = Math.sin((frame - delay) / 24) * 10;
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y + rise,
        fontFamily: theme.fonts.display,
        fontWeight: theme.weights.display,
        fontSize: size,
        lineHeight: 1,
        color: theme.colors.accent,
        opacity: Math.min(1, Math.max(0, p)) * 0.95,
        transform: `scale(${interpolate(p, [0, 1], [0.4, 1])}) rotate(-8deg)`,
        textShadow: `0 0 36px ${theme.colors.accentGlow}`,
      }}
    >
      Z
    </div>
  );
};

export const Hook: React.FC = () => {
  const frame = useCurrentFrame();
  const moon = useSpring(-8, "smooth");
  const float = Math.sin(frame / 34) * 12;
  return (
    <SceneShell>
      <AbsoluteFill>
        {STARS.map((s, i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              left: s.x,
              top: s.y,
              width: s.r * 2,
              height: s.r * 2,
              borderRadius: "50%",
              background: theme.colors.text,
              opacity: (0.25 + 0.55 * (0.5 + 0.5 * Math.sin(frame / 14 + s.ph))) * moon,
            }}
          />
        ))}

        {/* চাঁদ */}
        <div
          style={{
            position: "absolute",
            left: 270,
            top: 330 + float,
            width: 540,
            height: 540,
            opacity: Math.min(1, moon * 1.5),
            transform: `scale(${interpolate(moon, [0, 1], [0.86, 1])}) rotate(${interpolate(
              moon,
              [0, 1],
              [-14, 0],
            )}deg)`,
            filter: `drop-shadow(0 0 70px ${theme.colors.glow})`,
          }}
        >
          <svg viewBox="0 0 400 400" width="100%" height="100%">
            <defs>
              <mask id="hook-crescent">
                <rect width="400" height="400" fill="white" />
                <circle cx="272" cy="150" r="132" fill="black" />
              </mask>
            </defs>
            <circle cx="200" cy="210" r="150" fill={theme.colors.text} mask="url(#hook-crescent)" />
          </svg>
        </div>

        <Zed delay={14} size={120} x={760} y={380} />
        <Zed delay={22} size={86} x={860} y={300} />
        <Zed delay={30} size={60} x={930} y={240} />

        {/* শিরোনাম */}
        <div style={{ position: "absolute", left: 40, right: 40, top: 980 }}>
          <Words text="ঘুমের অভাবে" size={168} delay={-3} per={5} highlight={[1]} align="center" />
          <Words text="কী হয়?" size={168} delay={7} per={5} align="center" />
        </div>
      </AbsoluteFill>

      {/* হুক: খুব হালকা থাড + একটি পপ */}
      <Sfx name="thud" at={1} volume={0.27} />
      <Sfx name="pop" at={9} volume={0.26} rate={1.0} />
    </SceneShell>
  );
};
